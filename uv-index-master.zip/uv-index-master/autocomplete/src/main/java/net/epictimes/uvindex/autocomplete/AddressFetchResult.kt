package net.epictimes.uvindex.autocomplete

enum class AddressFetchResult {
    SUCCESS,
    FAIL
}