package net.epictimes.uvindex.ui

import android.support.v7.app.AppCompatActivity

abstract class BaseActivity : AppCompatActivity()
