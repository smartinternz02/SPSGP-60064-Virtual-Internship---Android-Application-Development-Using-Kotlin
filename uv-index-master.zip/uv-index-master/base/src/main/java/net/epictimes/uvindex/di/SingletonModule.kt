package net.epictimes.uvindex.di

import dagger.Module

@Module
class SingletonModule
