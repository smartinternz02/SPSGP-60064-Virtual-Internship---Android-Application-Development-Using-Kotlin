package net.epictimes.uvindex.di

import javax.inject.Scope

@kotlin.annotation.MustBeDocumented
@Scope
@kotlin.annotation.Retention
annotation class ActivityScoped
